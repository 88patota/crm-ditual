--
-- PostgreSQL database dump
--

\restrict BM1DjbeKgAELOAT1rXOd3I8976h140aufZv0zsEuZJcmr9NNoRGbNdK0utWIFZF

-- Dumped from database version 14.20 (Debian 14.20-1.pgdg13+1)
-- Dumped by pg_dump version 14.20 (Debian 14.20-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: userrole; Type: TYPE; Schema: public; Owner: crm_user
--

CREATE TYPE public.userrole AS ENUM (
    'admin',
    'vendas'
);


ALTER TYPE public.userrole OWNER TO crm_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version_user; Type: TABLE; Schema: public; Owner: crm_user
--

CREATE TABLE public.alembic_version_user (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version_user OWNER TO crm_user;

--
-- Name: budget_items; Type: TABLE; Schema: public; Owner: crm_user
--

CREATE TABLE public.budget_items (
    id integer NOT NULL,
    budget_id integer NOT NULL,
    description character varying NOT NULL,
    weight double precision,
    delivery_time character varying,
    purchase_value_with_icms double precision NOT NULL,
    purchase_icms_percentage double precision,
    purchase_other_expenses double precision,
    purchase_value_without_taxes double precision NOT NULL,
    purchase_value_with_weight_diff double precision,
    sale_weight double precision,
    sale_value_with_icms double precision NOT NULL,
    sale_icms_percentage double precision,
    sale_value_without_taxes double precision NOT NULL,
    weight_difference double precision,
    profitability double precision,
    total_profitability double precision,
    total_purchase double precision NOT NULL,
    total_sale double precision NOT NULL,
    unit_value double precision NOT NULL,
    total_value double precision NOT NULL,
    commission_percentage double precision,
    commission_percentage_actual double precision,
    commission_value double precision,
    ipi_percentage double precision,
    ipi_value double precision,
    total_value_with_ipi double precision,
    weight_difference_display text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.budget_items OWNER TO crm_user;

--
-- Name: budget_items_id_seq; Type: SEQUENCE; Schema: public; Owner: crm_user
--

CREATE SEQUENCE public.budget_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.budget_items_id_seq OWNER TO crm_user;

--
-- Name: budget_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: crm_user
--

ALTER SEQUENCE public.budget_items_id_seq OWNED BY public.budget_items.id;


--
-- Name: budgets; Type: TABLE; Schema: public; Owner: crm_user
--

CREATE TABLE public.budgets (
    id integer NOT NULL,
    order_number character varying NOT NULL,
    client_name character varying NOT NULL,
    client_id integer,
    total_purchase_value double precision,
    total_sale_value double precision,
    total_sale_with_icms double precision,
    total_commission double precision,
    commission_percentage_actual double precision,
    profitability_percentage double precision,
    total_ipi_value double precision,
    total_final_value double precision,
    total_weight_difference_percentage double precision,
    status character varying NOT NULL,
    notes text,
    created_by character varying NOT NULL,
    origem character varying(50),
    outras_despesas_totais double precision,
    freight_type character varying(10) NOT NULL,
    freight_value_total double precision,
    payment_condition character varying(50),
    valor_frete_compra double precision,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    expires_at timestamp with time zone
);


ALTER TABLE public.budgets OWNER TO crm_user;

--
-- Name: COLUMN budgets.outras_despesas_totais; Type: COMMENT; Schema: public; Owner: crm_user
--

COMMENT ON COLUMN public.budgets.outras_despesas_totais IS 'Outras despesas do pedido';


--
-- Name: COLUMN budgets.freight_value_total; Type: COMMENT; Schema: public; Owner: crm_user
--

COMMENT ON COLUMN public.budgets.freight_value_total IS 'Valor total do frete';


--
-- Name: COLUMN budgets.payment_condition; Type: COMMENT; Schema: public; Owner: crm_user
--

COMMENT ON COLUMN public.budgets.payment_condition IS 'Condições de pagamento';


--
-- Name: COLUMN budgets.valor_frete_compra; Type: COMMENT; Schema: public; Owner: crm_user
--

COMMENT ON COLUMN public.budgets.valor_frete_compra IS 'Valor do frete por kg (Valor Frete Total / Peso Total)';


--
-- Name: budgets_id_seq; Type: SEQUENCE; Schema: public; Owner: crm_user
--

CREATE SEQUENCE public.budgets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.budgets_id_seq OWNER TO crm_user;

--
-- Name: budgets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: crm_user
--

ALTER SEQUENCE public.budgets_id_seq OWNED BY public.budgets.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: crm_user
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email character varying(255) NOT NULL,
    username character varying(100) NOT NULL,
    full_name character varying(255) NOT NULL,
    hashed_password character varying(255) NOT NULL,
    role public.userrole NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.users OWNER TO crm_user;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: crm_user
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO crm_user;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: crm_user
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: budget_items id; Type: DEFAULT; Schema: public; Owner: crm_user
--

ALTER TABLE ONLY public.budget_items ALTER COLUMN id SET DEFAULT nextval('public.budget_items_id_seq'::regclass);


--
-- Name: budgets id; Type: DEFAULT; Schema: public; Owner: crm_user
--

ALTER TABLE ONLY public.budgets ALTER COLUMN id SET DEFAULT nextval('public.budgets_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: crm_user
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: alembic_version_user; Type: TABLE DATA; Schema: public; Owner: crm_user
--

COPY public.alembic_version_user (version_num) FROM stdin;
512
\.


--
-- Data for Name: budget_items; Type: TABLE DATA; Schema: public; Owner: crm_user
--

COPY public.budget_items (id, budget_id, description, weight, delivery_time, purchase_value_with_icms, purchase_icms_percentage, purchase_other_expenses, purchase_value_without_taxes, purchase_value_with_weight_diff, sale_weight, sale_value_with_icms, sale_icms_percentage, sale_value_without_taxes, weight_difference, profitability, total_profitability, total_purchase, total_sale, unit_value, total_value, commission_percentage, commission_percentage_actual, commission_value, ipi_percentage, ipi_value, total_value_with_ipi, weight_difference_display, created_at, updated_at) FROM stdin;
1	1	item	1000	3	2.11	0.18	0	1.570157	1.570157	1000	4.33	0.18	3.22217	0	105.21323663811964	105.21323663811964	1570.157	3222.17	0.003222	3222.17	0.05	0.05	216.5	0.0325	140.73	4470	{"has_difference": false, "absolute_difference": 0.0, "percentage_difference": 0.0, "formatted_display": ""}	2026-01-05 02:52:53.416453+00	2026-01-05 02:52:53.416453+00
2	2	item	3000	0	2.11	0.18	0	1.570157	1.570157	3000	4.33	0.18	3.22217	0	105.21323663811964	105.21323663811964	4710.471	9666.51	0.001074	9666.51	0.05	0.05	649.5	0.0325	422.18	13410	{"has_difference": false, "absolute_difference": 0.0, "percentage_difference": 0.0, "formatted_display": ""}	2026-01-05 03:40:21.118684+00	2026-01-05 03:40:21.118684+00
\.


--
-- Data for Name: budgets; Type: TABLE DATA; Schema: public; Owner: crm_user
--

COPY public.budgets (id, order_number, client_name, client_id, total_purchase_value, total_sale_value, total_sale_with_icms, total_commission, commission_percentage_actual, profitability_percentage, total_ipi_value, total_final_value, total_weight_difference_percentage, status, notes, created_by, origem, outras_despesas_totais, freight_type, freight_value_total, payment_condition, valor_frete_compra, created_at, updated_at, expires_at) FROM stdin;
1	PROP-00001	teste teste	\N	1570.157	3222.17	4330	216.5	0.05	1.0521323663811963	140.73	4470	0	draft	\N	admin	Email Vendas	0	FOB	\N	À vista	0	2026-01-05 02:52:53.416453+00	2026-01-05 02:52:53.416453+00	\N
2	PROP-00002	Teste teste	\N	4710.471	9666.51	12990	649.5	0.05	1.0521323663811963	422.18	13410	0	sent	\N	admin	\N	0	FOB	\N	À vista	0	2026-01-05 03:40:21.118684+00	2026-01-05 03:40:21.118684+00	\N
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: crm_user
--

COPY public.users (id, email, username, full_name, hashed_password, role, is_active, created_at, updated_at) FROM stdin;
1	admin@crmditual.com	admin	Administrador do Sistema	$2b$12$mQRo1OPv5kPOu9exZXhlYOAMQFfB35RIIBouVkidFatGoCy46zuP.	admin	t	2026-01-05 02:51:46.723725+00	2026-01-05 02:51:46.723725+00
\.


--
-- Name: budget_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: crm_user
--

SELECT pg_catalog.setval('public.budget_items_id_seq', 2, true);


--
-- Name: budgets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: crm_user
--

SELECT pg_catalog.setval('public.budgets_id_seq', 2, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: crm_user
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: alembic_version_user alembic_version_user_pkc; Type: CONSTRAINT; Schema: public; Owner: crm_user
--

ALTER TABLE ONLY public.alembic_version_user
    ADD CONSTRAINT alembic_version_user_pkc PRIMARY KEY (version_num);


--
-- Name: budget_items budget_items_pkey; Type: CONSTRAINT; Schema: public; Owner: crm_user
--

ALTER TABLE ONLY public.budget_items
    ADD CONSTRAINT budget_items_pkey PRIMARY KEY (id);


--
-- Name: budgets budgets_pkey; Type: CONSTRAINT; Schema: public; Owner: crm_user
--

ALTER TABLE ONLY public.budgets
    ADD CONSTRAINT budgets_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: crm_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: ix_budget_items_id; Type: INDEX; Schema: public; Owner: crm_user
--

CREATE INDEX ix_budget_items_id ON public.budget_items USING btree (id);


--
-- Name: ix_budgets_id; Type: INDEX; Schema: public; Owner: crm_user
--

CREATE INDEX ix_budgets_id ON public.budgets USING btree (id);


--
-- Name: ix_budgets_order_number; Type: INDEX; Schema: public; Owner: crm_user
--

CREATE UNIQUE INDEX ix_budgets_order_number ON public.budgets USING btree (order_number);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: crm_user
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_users_id; Type: INDEX; Schema: public; Owner: crm_user
--

CREATE INDEX ix_users_id ON public.users USING btree (id);


--
-- Name: ix_users_username; Type: INDEX; Schema: public; Owner: crm_user
--

CREATE UNIQUE INDEX ix_users_username ON public.users USING btree (username);


--
-- Name: budget_items budget_items_budget_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: crm_user
--

ALTER TABLE ONLY public.budget_items
    ADD CONSTRAINT budget_items_budget_id_fkey FOREIGN KEY (budget_id) REFERENCES public.budgets(id);


--
-- PostgreSQL database dump complete
--

\unrestrict BM1DjbeKgAELOAT1rXOd3I8976h140aufZv0zsEuZJcmr9NNoRGbNdK0utWIFZF

